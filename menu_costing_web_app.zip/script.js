let dishCount = 0;
const maxDishes = 10;
const form = document.getElementById("menuForm");
const resultDiv = document.getElementById("result");

function addDish() {
    if (dishCount >= maxDishes) return;
    const dishContainer = document.getElementById("dishes");
    const div = document.createElement("div");
    div.innerHTML = `
        <label>Dish ${dishCount + 1} Name:</label>
        <input type="text" required>
        <label>Cost Per Pax for Dish ${dishCount + 1} (₹):</label>
        <input type="number" step="0.01" required>
    `;
    dishContainer.appendChild(div);
    dishCount++;
}

form.onsubmit = function(e) {
    e.preventDefault();
    const pax = parseInt(document.getElementById("pax").value);
    const margin = parseFloat(document.getElementById("margin").value);
    const inputs = document.querySelectorAll("#dishes input");
    let totalCost = 0;
    for (let i = 1; i < inputs.length; i += 2) {
        const costPerPax = parseFloat(inputs[i].value);
        totalCost += costPerPax * pax;
    }
    const costPerPlate = totalCost / pax;
    const sellingPrice = costPerPlate * (1 + margin / 100);
    resultDiv.innerHTML = `
        <p><strong>Total Cost:</strong> ₹${totalCost.toFixed(2)}</p>
        <p><strong>Cost Per Plate:</strong> ₹${costPerPlate.toFixed(2)}</p>
        <p><strong>Suggested Selling Price Per Plate:</strong> ₹${sellingPrice.toFixed(2)}</p>
    `;
};
